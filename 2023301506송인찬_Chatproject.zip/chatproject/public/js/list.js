const roomListEl = document.getElementById("roomList");
const roomNameEl = document.getElementById("roomName");
const isPrivateEl = document.getElementById("isPrivate");
const roomPwEl = document.getElementById("roomPw");
const createBtnEl = document.getElementById("createBtn");

// server.js의 app.get('/api/rooms'... 이용해서 채팅방 목록 조회
async function loadRoomList() {
  const res = await fetch("/api/rooms", { method: "get" });
  const rooms = await res.json();
  roomListEl.innerHTML = "";

  rooms.forEach((r) => {
    const li = document.createElement("li");
    const a = document.createElement("a");
    if (r.isPrivate) a.textContent = r.name + "🔒";
    else a.textContent = r.name;

    // a.href = `room.html?room=${r.id}`;
    a.href = "#";
    a.addEventListener("click", async (e) => {
      e.preventDefault();

      // 공개방이라면 바로 입장
      if (!r.isPrivate) {
        location.href = `room.html?room=${r.id}`;
        return;
      }

      // 이전에 인증한 적 있는 비공개방일 경우, 서버에 해시 검증 요청
      const accessKey = `room_access_${r.id}`;
      const savedHash = sessionStorage.getItem(accessKey);

      if (savedHash) {
        const res = await fetch(`/api/rooms/${r.id}/check`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ hash: savedHash }),
        });

        const data = await res.json();
        if (data.success) {
          location.href = `room.html?room=${r.id}`;
          return;
        } else {
          sessionStorage.removeItem(accessKey); // 실패 시 해시 제거
        }
      }

      // 첫 접근 시, 비밀번호 입력 요청
      const password = prompt(`"${r.name}" 방의 비밀번호를 입력해주세요.`);
      if (!password) return;

      const res = await fetch(`api/rooms/${r.id}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();
      if (data.success) {
        sessionStorage.setItem(`room_access_${r.id}`, data.hash); // 인증 성공 시 해시 저장
        location.href = `room.html?room=${r.id}`;
      } else {
        // 메세지를 받지 못했을 경우
        alert(data.message || "방 입장에 실패했습니다.");
      }
    });

    li.append(a);
    roomListEl.append(li);
  });
}
loadRoomList();

// 비공개 체크박스로 비밀번호 toggle화
isPrivate.addEventListener("change", (e) => {
  if (e.target.checked) roomPwEl.style.display = "inline";
  else roomPwEl.style.display = "none";
});

// 채팅방 생성 버튼
createBtnEl.addEventListener("click", async () => {
  const name = roomNameEl.value;
  const isPrivate = isPrivateEl.checked;
  if (name === "") {
    alert("채팅방 이름을 입력하세요.");
    return;
  }
  const body = { name, isPrivate };
  if (isPrivate) {
    const pw = roomPwEl.value;
    if (pw === "") {
      alert("비밀번호를 입력하세요.");
      return;
    }
    body.password = pw;
  }
  const res = await fetch("/api/rooms", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    alert("채팅방 생성에 실패했습니다.");
    return;
  }
  roomNameEl.value = "";
  roomPwEl.value = "";
  isPrivateEl.checked = false;
  roomPwEl.style.display = "none";
  await loadRoomList();
});
