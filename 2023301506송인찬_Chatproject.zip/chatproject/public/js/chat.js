const params = new URLSearchParams(window.location.search);
const nicknameEl = document.getElementById("nickname");
const msgInputEl = document.getElementById("msgInput");
const sendBtnEl = document.getElementById("sendBtn");
const msgListEl = document.getElementById("msgList");
const roomTitleEl = document.getElementById("roomTitle");
const roomId = params.get("room");
let password = "";
let lastTs = 0;

function polling() {
  // 비밀번호 검증
  const accessKey = `room_access_${roomId}`;
  const savedHash = sessionStorage.getItem(accessKey);

  if (!savedHash) {
    alert("정상적인 요청이 아닙니다.");
    location.href = "index.html";
    return;
  }

  fetch(`/api/rooms/${roomId}/check`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ hash: savedHash }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (!data.success) {
        sessionStorage.removeItem(accessKey);
        alert("정상적인 요청이 아닙니다.");
        location.href = "index.html";
        return;
      }

      poll();
      setInterval(poll, 2000);
    })
    .catch(() => {
      alert("서버 오류입니다.");
      location.href = "index.html";
    });
}

async function poll() {
  const res = await fetch(`/api/rooms/${roomId}/messages`);
  if (!res.ok) return;
  const newMsgs = await res.json();
  newMsgs.forEach((m) => {
    if (m.timestamp > lastTs) {
      const li = document.createElement("li");
      li.textContent = `[${new Date(m.timestamp).toLocaleTimeString()}] ${
        m.user
      }: ${m.text}`;
      msgListEl.appendChild(li);
      lastTs = Math.max(lastTs, m.timestamp);
    }
  });
}

window.addEventListener("DOMContentLoaded", () => {
  polling();
});

sendBtnEl.addEventListener("click", async () => {
  const user = nicknameEl.value;
  const text = msgInputEl.value;
  if (!user || !text) {
    alert("닉네임과 메세지는 비울 수 없습니다.");
    return;
  }
  await fetch(`/api/rooms/${roomId}/messages`, {
    method: "post",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user, text }),
  });
  msgInputEl.value = "";
});

msgInputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    sendBtnEl.click();
  }
});
