const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const crypto = require("crypto");
const app = express();

const rooms = [];
const roomHashMap = new Map(); // key: roomId, value: roomHash
let nextRoomId = 1;
let nextMsgId = 1;

app.use(bodyParser.json());
app.use(express.static("public"));

// 검증을 위한 해시 생성 함수 추가
function getRoomHash(room) {
  return crypto
    .createHash("sha256")
    .update(`${room.id}-${room.name}-${room.createdAt}`)
    .digest("hex");
}

// 서버 id를 해시로 생성
function generateRoomId(name) {
  const raw = `${name}-${Date.now()}-${Math.random()}`;
  const id = crypto.createHash("md5").update(raw).digest("hex").slice(0, 8);

  if (rooms.some((r) => r.id === id)) {
    return generateRoomId(name);
  }

  return id;
}

// 채팅방 생성
app.post("/api/rooms", async (req, res) => {
  const { name, isPrivate, password } = req.body;
  const room = {
    id: generateRoomId(name),
    name,
    isPrivate: !!isPrivate,
    createdAt: new Date().toISOString(),
    messages: [],
  };

  room.hash = getRoomHash(room);
  roomHashMap.set(room.id, room.hash);

  if (room.isPrivate) {
    room.passwordHash = await bcrypt.hash(password || "", 10);
  }
  rooms.push(room);

  console.log(
    `[Debug] Room Created : id=${room.id} name="${room.name}" private=${room.isPrivate} hash=${room.hash}`
  );

  res
    .status(201)
    .json({ id: room.id, name: room.name, isPrivate: room.isPrivate });
});

// 비밀번호 확인용 api
app.post("/api/rooms/:id/verify", async (req, res) => {
  // 파라미터 받아와서
  const roomId = req.params.id;
  const { password } = req.body;

  // room 검증
  const room = rooms.find((r) => r.id === roomId);

  // 방이 없을 때
  if (!room) {
    return res
      .status(404)
      .json({ success: false, message: `선택한 방 (${roomId}) 이 없습니다.` });
  }

  // 방이 비공개가 아닐 때
  if (!room) {
    return res.status(400).json({ success: false, message: "공개방입니다." });
  }

  // 비밀번호 검증
  const isValidPw = await bcrypt.compare(password || "", room.passwordHash);
  if (isValidPw) {
    const hash = getRoomHash(room);
    return res.json({ success: true, hash });
  } else {
    return res
      .status(401)
      .json({ success: false, message: "비밀번호가 틀렸습니다." });
  }
});

// 이후 입장 검증 api
app.post("/api/rooms/:id/check", (req, res) => {
  const { hash } = req.body;
  const realHash = roomHashMap.get(req.params.id);

  if (!realHash) {
    return res.status(404).json({ success: false });
  }

  const match = hash === realHash;
  res.json({ success: match });
});

// 채팅방 목록 조회 (map을 이용해 조회용 새 배열 생성)
app.get("/api/rooms", (req, res) => {
  res.json(
    rooms.map((r) => ({
      id: r.id,
      name: r.name,
      isPrivate: r.isPrivate,
    }))
  );
});

// 메시지 조회
app.get("/api/rooms/:roomId/messages", (req, res) => {
  const roomId = req.params.roomId;
  const room = rooms.find((r) => r.id === roomId);
  if (!room) return res.sendStatus(404);
  const afterTime = Number(req.query.afterTime) || 0;
  const newMsgs = room.messages.filter((m) => m.timestamp > afterTime);
  res.json(newMsgs);
});

// 메시지 전송
app.post("/api/rooms/:roomId/messages", (req, res) => {
  // 파라미터 받아서
  const roomId = req.params.roomId;
  const room = rooms.find((r) => r.id === roomId);
  if (!room) return res.sendStatus(404);
  const { user, text } = req.body;
  const msg = { id: nextMsgId++, user, text, timestamp: Date.now() };
  // 메시지[]에 push
  room.messages.push(msg);

  console.log(room.messages);

  res.status(201).json(msg);
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running → http://localhost:${PORT}/index.html`);
});
